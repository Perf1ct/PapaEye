# Install PapaEye on a phone

PapaEye's phone app is a static PWA. Publish the **contents of this `pwa`
folder** to a static web host that serves HTTPS. Do not publish the whole
project: the PWA folder already contains its app files and trained model.

The host must serve `index.html` at the site root and allow the included
`manifest.json` and `sw.js` files. HTTPS is required for service workers and
installability outside `localhost`.

1. Open the published HTTPS address while online.
2. Wait until the header says `МОДЕЛИ ГОТОВЫ`.
3. On iPhone, open the address in Safari, tap Share, then choose **Add to Home
   Screen**.
4. On Android, open the address in Chrome and choose **Install app** or **Add
   to Home screen**.
5. Launch PapaEye from its home-screen icon. After the first successful load,
   the app and model are cached for offline use.

Text, code, and selected images are analyzed in the browser; content is not
uploaded. The hosting provider only serves the static app and model files.

When changing core PWA files, increment `CACHE_NAME` in `sw.js` so installed
copies replace their old offline cache.

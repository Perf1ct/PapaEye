(function (root) {
  "use strict";

  const STOP_WORDS = new Set(
    "и в во не что он на я с со как а то все она так его но да ты к у же вы за бы по только ее мне было вот от меня еще нет о из ему теперь когда даже ну вдруг ли если уже или ни быть был него до вас при для есть это эта эти the a an and or but if then of to in on for with is are was were be been being have has had do does did this that these those it its as by from".split(" ")
  );
  const WORD_RE = /[\p{L}\p{N}]+/gu;
  const SENTENCE_RE = /[.!?。！？]+/gu;

  function bounded(value, scale) {
    return Math.max(0, Math.min(1, value / scale));
  }

  function mean(values) {
    if (!values.length) return 0;
    return values.reduce((sum, value) => sum + value, 0) / values.length;
  }

  function pstdev(values) {
    if (values.length < 2) return 0;
    const average = mean(values);
    return Math.sqrt(mean(values.map((value) => (value - average) ** 2)));
  }

  function splitLines(value) {
    const lines = value.split(/\r\n|[\n\r\v\f\x1c-\x1e\x85\u2028\u2029]/u);
    if (lines.length > 1 && lines[lines.length - 1] === "") lines.pop();
    return lines;
  }

  function textFeatures(value) {
    const text = Array.from(value).slice(0, 100000).join("");
    const chars = Array.from(text);
    const charCount = chars.length;
    if (!charCount) throw new Error("Добавьте текст для анализа.");

    const words = text.toLowerCase().match(WORD_RE) || [text];
    const counts = new Map();
    for (const word of words) counts.set(word, (counts.get(word) || 0) + 1);
    const sentences = text.split(SENTENCE_RE).map((part) => part.trim()).filter(Boolean);
    const sentenceLengths = sentences.map((sentence) => (sentence.match(WORD_RE) || []).length);
    const wordLengths = words.map((word) => Array.from(word).length);
    let repeated = 0;
    for (let index = 1; index < words.length; index += 1) {
      if (words[index] === words[index - 1]) repeated += 1;
    }
    const charCounts = new Map();
    for (const character of Array.from(text.toLowerCase())) {
      charCounts.set(character, (charCounts.get(character) || 0) + 1);
    }
    let entropy = 0;
    for (const count of charCounts.values()) {
      const probability = count / charCount;
      entropy -= probability * Math.log2(probability);
    }
    const longWords = words.filter((word) => Array.from(word).length >= 12).length;
    const stopWords = words.filter((word) => STOP_WORDS.has(word)).length;
    const punctuation = chars.filter((character) => !/[\p{L}\p{N}]/u.test(character) && !/\s/u.test(character)).length;
    const uppercase = chars.filter((character) => character !== character.toLowerCase()).length;
    const digits = chars.filter((character) => /\p{N}/u.test(character)).length;
    const whitespace = chars.filter((character) => /\s/u.test(character)).length;
    const lines = splitLines(text);
    const sentenceMean = mean(sentenceLengths);
    const sentenceSpread = pstdev(sentenceLengths);
    const wordSpread = pstdev(wordLengths);
    const maxFrequency = Math.max(...counts.values());

    return [
      bounded(Math.log1p(charCount), Math.log1p(100000)),
      bounded(Math.log1p(words.length), Math.log1p(100000)),
      bounded(mean(wordLengths), 20),
      bounded(counts.size / words.length, 1),
      bounded(punctuation / charCount, 0.35),
      bounded(uppercase / charCount, 0.5),
      bounded(digits / charCount, 0.5),
      bounded(whitespace / charCount, 0.5),
      bounded((lines.length - 1) / Math.max(charCount, 1), 0.2),
      bounded(sentenceMean, 40),
      bounded(sentenceSpread, 30),
      bounded(wordSpread, 12),
      bounded(maxFrequency / words.length, 0.5),
      bounded(stopWords / words.length, 1),
      bounded(longWords / words.length, 0.5),
      bounded(repeated / Math.max(words.length - 1, 1), 0.5),
      bounded(entropy, 8),
      bounded(Array.from(text).filter((character) => ",;:".includes(character)).length / charCount, 0.2),
      bounded(Array.from(text).filter((character) => "-*#>".includes(character)).length / charCount, 0.2),
    ];
  }

  function codeFeatures(value) {
    const code = Array.from(value).slice(0, 100000).join("");
    if (!code.trim()) throw new Error("Добавьте исходный код для анализа.");

    const lines = splitLines(code);
    const nonempty = lines.filter((line) => line.trim());
    const stripped = nonempty.map((line) => line.replace(/^[ \t]*/u, ""));
    const tokens = code.match(/[A-Za-z_$][A-Za-z0-9_$]*|\d+|[^\s]/gu) || [];
    const identifiers = code.match(/[A-Za-z_$][A-Za-z0-9_$]*/gu) || [];
    const counts = new Map();
    for (const identifier of identifiers) counts.set(identifier, (counts.get(identifier) || 0) + 1);
    const comments = lines.filter((line) => /^\s*(?:#|\/\/|\/\*|\*|<!--)/u.test(line)).length;
    const indents = nonempty.map((line) => (line.match(/^[ \t]*/u) || [""])[0].length);
    const indentDeltas = indents.slice(1).map((indent, index) => Math.abs(indent - indents[index])).filter(Boolean);
    const lengths = nonempty.map((line) => Array.from(line).length);
    if (!lengths.length) lengths.push(0);
    let repeatedIdentifiers = 0;
    for (const count of counts.values()) repeatedIdentifiers += count - 1;
    const operators = tokens.filter((token) => ["=", "==", "=>", "+", "-", "*", "/", "&&", "||"].includes(token)).length;
    const numbers = code.match(/(?<![\w.])\d+(?:\.\d+)?/gu) || [];
    const docMarkers = (code.match(/("""|'''|\/\*\*|TODO|FIXME)/gu) || []).length;
    const functionMarkers = (code.match(/\b(def|function|func|fn|class)\b|=>/gu) || []).length;
    const controlMarkers = (code.match(/\b(if|else|for|while|switch|match|try|catch)\b/gu) || []).length;
    const typingMarkers = (code.match(/(:\s*(str|int|float|bool|List|Dict|Optional)|->\s*\w)/gu) || []).length;
    const commentLines = Math.max(comments, 1);

    return [
      bounded(Math.log1p(Array.from(code).length), Math.log1p(100000)),
      bounded(lines.length / Math.max(Array.from(code).length, 1), 0.2),
      bounded(mean(lengths), 140),
      bounded(lengths.filter((length) => length > 120).length / lengths.length, 0.5),
      bounded(comments / Math.max(lines.length, 1), 0.5),
      bounded(mean(stripped.map((line) => Array.from(line).length)), 80),
      bounded(pstdev(indents), 12),
      bounded(mean(indentDeltas), 8),
      bounded(identifiers.length / Math.max(tokens.length, 1), 1),
      bounded(mean(identifiers.map((identifier) => Array.from(identifier).length)), 30),
      bounded(repeatedIdentifiers / Math.max(identifiers.length, 1), 1),
      bounded(operators / Math.max(tokens.length, 1), 0.5),
      bounded(numbers.length / Math.max(tokens.length, 1), 0.5),
      bounded(functionMarkers / Math.max(lines.length, 1), 0.5),
      bounded(controlMarkers / Math.max(lines.length, 1), 0.5),
      bounded(typingMarkers / Math.max(lines.length, 1), 0.5),
      bounded(docMarkers / commentLines, 1),
      bounded(Array.from(code).filter((character) => "{}[]();".includes(character)).length / Math.max(Array.from(code).length, 1), 0.5),
    ];
  }

  function imageFeaturesFromPixels(width, height, rgba, metadata, originalWidth, originalHeight) {
    const pixelCount = width * height;
    if (width !== 32 || height !== 32 || rgba.length !== pixelCount * 4) {
      throw new Error("Не удалось подготовить изображение 32 × 32.");
    }
    const pixels = [];
    const grayPixels = [];
    const histogram = new Array(256).fill(0);
    let redSum = 0;
    let greenSum = 0;
    let blueSum = 0;
    let redSquares = 0;
    let greenSquares = 0;
    let blueSquares = 0;
    let colorSum = 0;
    let darkPixels = 0;
    let brightPixels = 0;
    const unique = new Set();
    for (let index = 0; index < rgba.length; index += 4) {
      const red = rgba[index];
      const green = rgba[index + 1];
      const blue = rgba[index + 2];
      redSum += red;
      greenSum += green;
      blueSum += blue;
      redSquares += red * red;
      greenSquares += green * green;
      blueSquares += blue * blue;
      colorSum += Math.max(red, green, blue) - Math.min(red, green, blue);
      pixels.push([red, green, blue]);
      unique.add(red + "," + green + "," + blue);
      const gray = (19595 * red + 38470 * green + 7471 * blue + 32768) >> 16;
      grayPixels.push(gray);
      histogram[gray] += 1;
      if (gray < 16) darkPixels += 1;
      if (gray > 239) brightPixels += 1;
    }
    const channelMeans = [redSum, greenSum, blueSum].map((sum) => sum / pixelCount);
    const meanChannel = mean(channelMeans);
    const meanStddev = mean(
      [redSquares, greenSquares, blueSquares].map((sum, index) =>
        Math.sqrt(Math.max(0, sum / pixelCount - channelMeans[index] ** 2))
      )
    );
    let entropy = 0;
    for (const count of histogram) {
      if (!count) continue;
      const probability = count / pixelCount;
      entropy -= probability * Math.log2(probability);
    }
    let edgeSum = 0;
    for (let index = 1; index < grayPixels.length; index += 1) {
      edgeSum += Math.abs(grayPixels[index] - grayPixels[index - 1]);
    }
    const info = metadata || {};
    return [
      1, 1,
      bounded((originalWidth || width) / Math.max(originalHeight || height, 1), 4),
      bounded((originalHeight || height) / Math.max(originalWidth || width, 1), 4),
      bounded(entropy, 8), bounded(meanChannel, 255), bounded(meanStddev, 128),
      bounded(edgeSum / Math.max(pixelCount - 1, 1), 128), bounded(colorSum / pixelCount, 255),
      bounded(unique.size / pixelCount, 1), bounded(pixelCount / 1024, 1),
      bounded(darkPixels / pixelCount, 1), bounded(brightPixels / pixelCount, 1),
      bounded(info.hasExif ? 1 : 0, 1), bounded(info.hasTextMetadata ? 1 : 0, 1),
      bounded(info.generatorMarker ? 1 : 0, 1),
    ];
  }

  function sigmoid(value) {
    if (value >= 0) {
      const z = Math.exp(-Math.min(value, 60));
      return 1 / (1 + z);
    }
    const z = Math.exp(Math.max(value, -60));
    return z / (1 + z);
  }

  function predict(model, features) {
    if (!model || features.length !== model.input_size) {
      throw new Error("Размер входных признаков не совпадает с моделью.");
    }
    const hidden = model.w1.map((weights, index) => {
      let sum = model.b1[index];
      for (let feature = 0; feature < features.length; feature += 1) {
        sum += weights[feature] * features[feature];
      }
      return sigmoid(sum);
    });
    let output = model.b2;
    for (let index = 0; index < hidden.length; index += 1) {
      output += model.w2[index] * hidden[index];
    }
    return sigmoid(output);
  }

  const api = { textFeatures, codeFeatures, imageFeaturesFromPixels, predict };
  root.PapaEyeModel = api;
  if (typeof module !== "undefined" && module.exports) module.exports = api;
})(typeof globalThis !== "undefined" ? globalThis : this);

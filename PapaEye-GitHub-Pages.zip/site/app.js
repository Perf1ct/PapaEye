(function () {
  "use strict";

  const MAX_TEXT_CHARS = 100000;
  const MAX_IMAGE_BYTES = 20 * 1024 * 1024;
  const MODES = {
    text: { label: "Текст для анализа", modelLabel: "Английские ответы HC3" },
    code: { label: "Исходный код для анализа", modelLabel: "Python-код из парных задач" },
    image: { label: "Изображение для анализа", modelLabel: "CIFAKE · низкое разрешение 32 × 32" },
  };
  const elements = {
    modeButtons: Array.from(document.querySelectorAll(".mode-button")),
    inputLabel: document.getElementById("input-label"),
    textEntry: document.getElementById("text-entry"),
    textInput: document.getElementById("content-input"),
    textFile: document.getElementById("text-file-input"),
    textFileButton: document.getElementById("text-file-button"),
    selectedFile: document.getElementById("selected-file"),
    charCount: document.getElementById("char-count"),
    imageEntry: document.getElementById("image-entry"),
    imageInput: document.getElementById("image-input"),
    imagePicker: document.getElementById("image-picker"),
    imagePreview: document.getElementById("image-preview"),
    removeImage: document.getElementById("remove-image"),
    analyze: document.getElementById("analyze-button"),
    clear: document.getElementById("clear-button"),
    result: document.getElementById("result-card"),
    resultKicker: document.getElementById("result-kicker"),
    resultDomain: document.getElementById("result-domain"),
    resultVerdict: document.getElementById("result-verdict"),
    scoreFill: document.getElementById("score-fill"),
    scoreValue: document.getElementById("score-value"),
    resultDetail: document.getElementById("result-detail"),
    error: document.getElementById("error-card"),
    connection: document.getElementById("connection-label"),
    installButton: document.getElementById("install-button"),
    aboutDialog: document.getElementById("about-dialog"),
    installDialog: document.getElementById("install-dialog"),
    installInstructions: document.getElementById("install-instructions"),
    installConfirm: document.getElementById("install-confirm"),
  };

  let mode = "text";
  let selectedImage = null;
  let installPrompt = null;
  let models = null;
  let previewUrl = null;

  function setMode(nextMode) {
    mode = nextMode;
    for (const button of elements.modeButtons) {
      const active = button.dataset.mode === mode;
      button.classList.toggle("active", active);
      button.setAttribute("aria-selected", String(active));
    }
    const imageMode = mode === "image";
    elements.inputLabel.textContent = MODES[mode].label;
    elements.textEntry.hidden = imageMode;
    elements.textFileButton.hidden = imageMode;
    elements.textFile.hidden = imageMode;
    elements.charCount.hidden = imageMode;
    elements.imageEntry.hidden = !imageMode;
    clearResult();
  }

  function setError(message) {
    elements.error.textContent = message;
    elements.error.hidden = false;
  }

  function clearResult() {
    elements.error.hidden = true;
    elements.result.hidden = true;
  }

  function setImage(file) {
    if (!file) return;
    if (!file.type.startsWith("image/")) {
      setError("Выбери файл изображения.");
      return;
    }
    if (file.size > MAX_IMAGE_BYTES) {
      setError("Размер изображения превышает 20 МБ.");
      return;
    }
    selectedImage = file;
    clearResult();
    if (previewUrl) URL.revokeObjectURL(previewUrl);
    previewUrl = URL.createObjectURL(file);
    elements.imagePreview.src = previewUrl;
    elements.imagePreview.hidden = false;
    elements.imagePicker.hidden = true;
    elements.removeImage.hidden = false;
    elements.selectedFile.textContent = file.name;
  }

  function resetImage() {
    selectedImage = null;
    elements.imageInput.value = "";
    elements.imagePreview.hidden = true;
    elements.imagePreview.removeAttribute("src");
    elements.imagePicker.hidden = false;
    elements.removeImage.hidden = true;
    elements.selectedFile.textContent = "";
    if (previewUrl) URL.revokeObjectURL(previewUrl);
    previewUrl = null;
    clearResult();
  }

  function showResult(score, model) {
    const percentage = score * 100;
    const verdict = score >= 0.65
      ? "Модель склоняется к классу «ИИ»"
      : score <= 0.35
        ? "Модель склоняется к классу «человек»"
        : "Результат неопределённый";
    elements.resultKicker.textContent = "РЕЗУЛЬТАТ МОДЕЛИ";
    elements.resultDomain.textContent = MODES[mode].modelLabel;
    elements.resultVerdict.textContent = verdict;
    elements.scoreFill.style.width = percentage.toFixed(1) + "%";
    elements.scoreValue.textContent = percentage.toFixed(1) + "%";
    const accuracy = (model.validation_balanced_accuracy * 100).toFixed(1);
    elements.resultDetail.textContent =
      "Оценка нейросети (не калиброванная вероятность). На отложенных примерах этого бенчмарка: " +
      accuracy + "% сбалансированной точности (" + model.validation_samples + " примеров).";
    elements.result.hidden = false;
    elements.error.hidden = true;
  }

  function imagePixels(file) {
    return new Promise((resolve, reject) => {
      const image = new Image();
      const url = URL.createObjectURL(file);
      image.onload = () => {
        try {
          const canvas = document.createElement("canvas");
          canvas.width = 32;
          canvas.height = 32;
          const context = canvas.getContext("2d", { willReadFrequently: true });
          if (!context) throw new Error("Браузер не смог открыть обработчик изображения.");
          context.imageSmoothingEnabled = true;
          context.imageSmoothingQuality = "low";
          context.drawImage(image, 0, 0, 32, 32);
          const pixels = context.getImageData(0, 0, 32, 32).data;
          URL.revokeObjectURL(url);
          resolve({
            pixels: Array.from(pixels),
            width: image.naturalWidth,
            height: image.naturalHeight,
          });
        } catch (error) {
          URL.revokeObjectURL(url);
          reject(error);
        }
      };
      image.onerror = () => {
        URL.revokeObjectURL(url);
        reject(new Error("Не удалось прочитать это изображение."));
      };
      image.src = url;
    });
  }

  async function analyze() {
    clearResult();
    if (!models) {
      setError("Локальная модель не загрузилась. Перезагрузи приложение, когда будешь онлайн.");
      return;
    }
    elements.analyze.disabled = true;
    elements.analyze.querySelector("span:first-child").textContent = "Анализирую…";
    try {
      let features;
      if (mode === "image") {
        if (!selectedImage) throw new Error("Сначала выбери изображение.");
        const image = await imagePixels(selectedImage);
        features = PapaEyeModel.imageFeaturesFromPixels(
          32, 32, image.pixels, {}, image.width, image.height
        );
      } else {
        const text = elements.textInput.value;
        if (!text.trim()) throw new Error("Добавь текст или код для анализа.");
        if (Array.from(text).length > MAX_TEXT_CHARS) throw new Error("Максимальная длина — 100 000 символов.");
        features = mode === "code"
          ? PapaEyeModel.codeFeatures(text)
          : PapaEyeModel.textFeatures(text);
      }
      const model = models[mode];
      if (!model) throw new Error("Для этого типа содержимого нет встроенной модели.");
      showResult(PapaEyeModel.predict(model, features), model);
    } catch (error) {
      setError(error instanceof Error ? error.message : "Не удалось выполнить анализ.");
    } finally {
      elements.analyze.disabled = false;
      elements.analyze.querySelector("span:first-child").textContent = "Анализировать";
    }
  }

  function updateCount() {
    const length = Array.from(elements.textInput.value).length;
    elements.charCount.textContent = length.toLocaleString("ru-RU") + " / 100 000";
  }

  function clearAll() {
    elements.textInput.value = "";
    elements.textFile.value = "";
    elements.selectedFile.textContent = "";
    resetImage();
    updateCount();
    clearResult();
  }

  async function installApp() {
    if (installPrompt) {
      installPrompt.prompt();
      await installPrompt.userChoice;
      installPrompt = null;
      elements.installButton.hidden = true;
      return;
    }
    const isIos = /iphone|ipad|ipod/i.test(navigator.userAgent);
    elements.installInstructions.textContent = isIos
      ? "Открой PapaEye в Safari, нажми кнопку «Поделиться» и выбери «На экран Домой»."
      : "Открой меню браузера и выбери «Установить приложение» или «Добавить на главный экран».";
    elements.installConfirm.hidden = true;
    elements.installDialog.showModal();
  }

  async function initialize() {
    try {
      const response = await fetch("./models.json", { cache: "no-cache" });
      if (!response.ok) throw new Error("Модели недоступны.");
      models = await response.json();
      elements.connection.textContent = "МОДЕЛИ ГОТОВЫ";
    } catch {
      elements.connection.textContent = "НЕТ СВЯЗИ";
    }
    if ("serviceWorker" in navigator && window.isSecureContext) {
      navigator.serviceWorker.register("./sw.js").catch(() => {
        elements.connection.textContent = "ОНЛАЙН";
      });
    }
    const isIos = /iphone|ipad|ipod/i.test(navigator.userAgent);
    const isInstalled = window.matchMedia("(display-mode: standalone)").matches ||
      navigator.standalone === true;
    if (isIos && !isInstalled) elements.installButton.hidden = false;
  }

  for (const button of elements.modeButtons) {
    button.addEventListener("click", () => setMode(button.dataset.mode));
  }
  elements.textInput.addEventListener("input", updateCount);
  elements.analyze.addEventListener("click", analyze);
  elements.clear.addEventListener("click", clearAll);
  elements.imagePicker.addEventListener("click", () => elements.imageInput.click());
  elements.imageInput.addEventListener("change", () => setImage(elements.imageInput.files[0]));
  elements.removeImage.addEventListener("click", resetImage);
  elements.aboutDialog.addEventListener("click", (event) => {
    if (event.target === elements.aboutDialog) elements.aboutDialog.close();
  });
  document.getElementById("about-button").addEventListener("click", () => elements.aboutDialog.showModal());
  document.getElementById("dialog-close").addEventListener("click", () => elements.aboutDialog.close());
  document.getElementById("install-dialog-close").addEventListener("click", () => elements.installDialog.close());
  elements.installButton.addEventListener("click", installApp);
  elements.installConfirm.addEventListener("click", installApp);
  elements.textFile.addEventListener("change", async () => {
    const file = elements.textFile.files[0];
    if (!file) return;
    if (file.size > MAX_TEXT_CHARS * 4) {
      setError("Этот файл слишком большой для локальной проверки.");
      return;
    }
    try {
      const content = await file.text();
      if (Array.from(content).length > MAX_TEXT_CHARS) throw new Error("Файл длиннее 100 000 символов.");
      elements.textInput.value = content;
      elements.selectedFile.textContent = file.name;
      updateCount();
      clearResult();
    } catch (error) {
      setError(error instanceof Error ? error.message : "Не удалось прочитать файл.");
    }
  });
  document.addEventListener("dragover", (event) => event.preventDefault());
  document.addEventListener("drop", (event) => {
    event.preventDefault();
    const file = event.dataTransfer && event.dataTransfer.files[0];
    if (!file) return;
    if (file.type.startsWith("image/")) {
      setMode("image");
      setImage(file);
    } else {
      setMode("text");
      if (file.size > MAX_TEXT_CHARS * 4) return setError("Этот файл слишком большой.");
      file.text().then((content) => {
        if (Array.from(content).length > MAX_TEXT_CHARS) return setError("Файл длиннее 100 000 символов.");
        elements.textInput.value = content;
        elements.selectedFile.textContent = file.name;
        updateCount();
      }).catch(() => setError("Не удалось прочитать этот файл."));
    }
  });
  window.addEventListener("beforeinstallprompt", (event) => {
    event.preventDefault();
    installPrompt = event;
    elements.installButton.hidden = false;
  });
  window.addEventListener("appinstalled", () => {
    elements.installButton.hidden = true;
    installPrompt = null;
  });

  updateCount();
  initialize();
})();

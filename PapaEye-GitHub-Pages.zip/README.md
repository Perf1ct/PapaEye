# PapaEye GitHub Pages bundle

This bundle publishes **only the static PWA** in `site/`. It does not contain
the Windows source code or training datasets.

1. Create a new empty **public** GitHub repository.
2. Extract this ZIP and publish its contents as the repository's `main` branch.
   GitHub Desktop can create/publish a local repository from the extracted
   folder; alternatively, use Git from that folder:

   ```powershell
   git init -b main
   git add .
   git commit -m "Publish PapaEye mobile app"
   git remote add origin https://github.com/YOUR-NAME/YOUR-REPOSITORY.git
   git push -u origin main
   ```

3. In the repository, open **Settings → Pages** and set the source to
   **GitHub Actions**.
4. Wait for the **Deploy PapaEye to GitHub Pages** workflow to finish. The
   repository's Pages settings show the published URL.
5. On iPhone, open that HTTPS URL in Safari and choose **Share → Add to Home
   Screen**. On Android, open it in Chrome and choose **Install app** / **Add to
   Home screen**.

The app and model run in the browser. The repository serves static files;
submitted text, code, and images are not uploaded.
